from .myworm import *

__doc__ = myworm.__doc__
